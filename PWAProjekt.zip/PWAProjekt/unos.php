<?php
session_start();
include 'connect.php';
define('UPLPATH', 'img/');
if (isset($_GET['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to the login page
    exit();
}
// Provjera da li je korisnik došao s login forme
if (isset($_POST['prijava'])) {
    // Provjera da li korisnik postoji u bazi uz zaštitu od SQL injectiona
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];
    $sql = "SELECT korisnickoime, lozinka, razina FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    // Provjera lozinke
    if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
        $uspjesnaPrijava = true;
        // Postavljanje session varijabli
        $_SESSION['username'] = $imeKorisnika;
        $_SESSION['level'] = $levelKorisnika;
    } else {
        $uspjesnaPrijava = false;
    }
}

// Provjera da li je korisnik prijavljen i ima razinu 1
if (isset($_SESSION['username']) && isset($_SESSION['level'])) {
    if ($_SESSION['level'] == 0) {
        echo 'Nemate pristup ovoj stranici.';
    } else if ($_SESSION['level'] == 1) {
        $query = "SELECT * FROM vijesti";
        $result = mysqli_query($dbc, $query);
        echo '<table>';
        while ($row = mysqli_fetch_array($result)) {
            echo '<tr>';
            echo '<td>' . $row['naslov'] . '</td>';
            echo '<td>' . $row['sazetak'] . '</td>';
            echo '<td>' . $row['datum'] . '</td>';
            echo '<td><a href="update.php?id=' . $row['id'] . '">Uredi</a></td>';
            echo '<td>
                    <form method="post" action="">
                      <input type="hidden" name="id" value="' . $row['id'] . '">
                      <input type="submit" name="delete" value="Obriši">
                    </form>
                  </td>';
            echo '</tr>';
        }
        echo '</table>';

        // Dodatak za odjavu
        echo '<a href="?logout=true">Odjava</a>';
    }
}
?>

<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L'Express</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <header>
            <div><img src="img/logo.png" alt="logo" class="lexpress"></div>
        </header>
    </div>

    <nav class="navigacija">
        <div class="nav">
            <div class="container2">
                <a href="index.php">HOME</a>
                <a href="administracija.php">ADMINISTRACIJA</a>
                <a href="registracija.php">REGISTRACIJA</a>
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<a href="index.php?logout=true">ODJAVI SE</a>'; // Add the logout link
                } else {
                    echo '<a href="login.php">PRIJAVA</a>';
                }
                ?>
                <a href="unos.php" class="aktivan">UNOS VIJESTI</a>
                <a href="kategorija.php?id=SPORT">SPORT</a>
                <a href="kategorija.php?id=POLITIKA">POLITIKA</a>
            </div>
        </div>
    </nav>

    <nav class="navigacija2"></nav>

    <div class="srednji">
        <div class="container2">
            <div class="content1">
                <?php 
                if (isset($_SESSION['username']) && $_SESSION['razina'] == 1){
                    echo '
                <form action="unos.php" method="POST" id="forma">
                    <div>
                        <label for="title">Naslov vijesti</label>
                        <div>
                            <input type="text" name="title" id="title" class="form-field-textual">
                        </div>
                        <div id="porukaTitle" class="poruka"></div> <!-- Dodan element za prikaz poruke pogreške -->
                    </div>

                    <div>
                        <label for="date">Datum</label>
                        <div>
                            <input type="date" name="date" id="date" class="form-field-textual">
                        </div>
                        <div id="porukaDate" class="poruka"></div> <!-- Dodan element za prikaz poruke pogreške -->
                    </div>

                    <div>
                        <label for="about">Kratki sadržaj vijesti (do 50 znakova)</label>
                        <div>
                            <textarea name="about" id="about" cols="30" rows="10" class="form-field-textual"></textarea>
                        </div>
                        <div id="porukaAbout" class="poruka"></div> <!-- Dodan element za prikaz poruke pogreške -->
                    </div>

                    <div>
                        <label for="content">Sadržaj vijesti</label>
                        <div>
                            <textarea name="content" id="content" cols="30" rows="10" class="form-field-textual"></textarea>
                        </div>
                        <div id="porukaContent" class="poruka"></div> <!-- Dodan element za prikaz poruke pogreške -->
                    </div>

                    <div>
                        <label for="pphoto">Slika:</label>
                        <div>
                            <input type="file" accept="image/jpg,image/gif,image/jpeg,image/png" name="pphoto" id="pphoto" />
                        </div>
                        <div id="porukaSlika" class="poruka"></div> <!-- Dodan element za prikaz poruke pogreške -->
                    </div>

                    <div>
                        <label for="category">Kategorija vijesti</label>
                        <div>
                            <select name="category" id="category" class="form-field-textual">
                                <option value="SPORT">Sport</option>
                                <option value="POLITIKA">Politika</option>
                            </select>
                        </div>
                        <div id="porukaKategorija" class="poruka"></div> <!-- Dodan element za prikaz poruke pogreške -->
                    </div>

                    <div>
                        <label>Spremiti u arhivu:</label>
                        <div>
                            <input type="checkbox" name="archive" id="archive">
                        </div>
                    </div>
                    <div>
                        <button type="reset" value="Poništi" class="gumb">Poništi</button>
                        <button type="submit" value="Prihvati" class="gumb" id="slanje">Prihvati</button>
                    </div>
                </form>
                ';}
                else {
                    echo 'Nemate pristup ovoj stranici.';
                }
                ?>
            </div>
        </div>

    </div>
    <footer class="footer">
        <div class="container">
            <div class="container2">
                @ L'Express - Karlo Žerjav
            </div>
        </div>
    </footer>

    <script type="text/javascript">
        // Provjera forme prije slanja
        document.getElementById("slanje").onclick = function(event) {
            var slanjeForme = true;

            // Naslov vjesti (5-30 znakova)
            var poljeTitle = document.getElementById("title");
            var title = poljeTitle.value;
            if (title.length === 0) {
                slanjeForme = false;
                poljeTitle.style.border = "1px dashed red";
                document.getElementById("porukaTitle").innerHTML = "Naslov vijesti mora biti unesen!<br>";
                document.getElementById("porukaTitle").style.color = "red";
            } else if (title.length < 5 || title.length > 30) {
                slanjeForme = false;
                poljeTitle.style.border = "1px dashed red";
                document.getElementById("porukaTitle").innerHTML = "Naslov vjesti mora imati između 5 i 30 znakova!<br>";
                document.getElementById("porukaTitle").style.color = "red";
            } else {
                poljeTitle.style.border = "2px solid green";
                document.getElementById("porukaTitle").innerHTML = "";
                document.getElementById("porukaTitle").style.color = "green";
            }

            // Datum
            var poljeDate = document.getElementById("date");
            var date = poljeDate.value;
            if (date.length === 0) {
                slanjeForme = false;
                poljeDate.style.border = "1px dashed red";
                document.getElementById("porukaDate").innerHTML = "Datum mora biti unesen!<br>";
                document.getElementById("porukaDate").style.color = "red";
            } else if (!isValidDate(date)) {
                slanjeForme = false;
                poljeDate.style.border = "1px dashed red";
                document.getElementById("porukaDate").innerHTML = "Datum mora biti ispravnog formata (YYYY-MM-DD)!";
                document.getElementById("porukaDate").style.color = "red";
            } else {
                poljeDate.style.border = "2px solid green";
                document.getElementById("porukaDate").innerHTML = "";
                document.getElementById("porukaDate").style.color = "green";
            }

            // Kratki sadržaj (10-100 znakova)
            var poljeAbout = document.getElementById("about");
            var about = poljeAbout.value;
            if (about.length === 0) {
                slanjeForme = false;
                poljeAbout.style.border = "1px dashed red";
                document.getElementById("porukaAbout").innerHTML = "Kratki sadržaj mora biti unesen!<br>";
                document.getElementById("porukaAbout").style.color = "red";
            } else if (about.length < 10 || about.length > 100) {
                slanjeForme = false;
                poljeAbout.style.border = "1px dashed red";
                document.getElementById("porukaAbout").innerHTML = "Kratki sadržaj mora imati između 10 i 100 znakova!<br>";
                document.getElementById("porukaAbout").style.color = "red";
            } else {
                poljeAbout.style.border = "2px solid green";
                document.getElementById("porukaAbout").innerHTML = "";
                document.getElementById("porukaAbout").style.color = "green";
            }

            // Sadržaj mora biti unesen
            var poljeContent = document.getElementById("content");
            var content = poljeContent.value;
            if (content.length === 0) {
                slanjeForme = false;
                poljeContent.style.border = "1px dashed red";
                document.getElementById("porukaContent").innerHTML = "Sadržaj mora biti unesen!<br>";
                document.getElementById("porukaContent").style.color = "red";
            } else {
                poljeContent.style.border = "2px solid green";
                document.getElementById("porukaContent").innerHTML = "";
                document.getElementById("porukaContent").style.color = "green";
            }

            // Slika mora biti unesena
            var poljeSlika = document.getElementById("pphoto");
            var pphoto = poljeSlika.value;
            if (pphoto.length === 0) {
                slanjeForme = false;
                poljeSlika.style.border = "1px dashed red";
                document.getElementById("porukaSlika").innerHTML = "Slika mora biti unesena!<br>";
                document.getElementById("porukaSlika").style.color = "red";
            } else {
                poljeSlika.style.border = "2px solid green";
                document.getElementById("porukaSlika").innerHTML = "";
                document.getElementById("porukaSlika").style.color = "green";
            }

            // Kategorija mora biti odabrana
            var poljeCategory = document.getElementById("category");
            if (poljeCategory.selectedIndex === 1) {
                poljeCategory.style.border = "2px solid green";
                document.getElementById("porukaKategorija").innerHTML = "";
                document.getElementById("porukaKategorija").style.color = "green";
            } else {
                poljeCategory.style.border = "2px solid green";
                document.getElementById("porukaKategorija").innerHTML = "";
                document.getElementById("porukaKategorija").style.color = "green";
            }

            // Provjera ispravnosti formata datuma
            function isValidDate(dateString) {
                var regEx = /^\d{4}-\d{2}-\d{2}$/;
                if (!dateString.match(regEx)) return false; // Neispravan format datuma
                var d = new Date(dateString);
                var dNum = d.getTime();
                if (!dNum && dNum !== 0) return false; // Neispravan datum
                return d.toISOString().slice(0, 10) === dateString;
            }

            if (!slanjeForme) {
                event.preventDefault();
            }
        };
    </script>



</body>

</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'connect.php';
    $naslov = $_POST["title"];
    $datum = $_POST['date'];
    $kratki_sadrzaj = $_POST["about"];
    $sadrzaj = $_POST["content"];
    $slika = $_POST["pphoto"];
    $kategorija = $_POST["category"];
    $archive = isset($_POST['archive']) ? 1 : 0;


    $target_dir = 'img/' . $slika;
    move_uploaded_file($_POST["pphoto"], $target_dir);
    $query = "INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva ) VALUES ('$datum', '$naslov', '$kratki_sadrzaj', '$sadrzaj', '$slika', '$kategorija', '$archive')";
    $result = mysqli_query($dbc, $query) or die('Error querying databese.');
    mysqli_close($dbc);
}
?>