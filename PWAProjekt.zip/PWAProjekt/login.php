<?php
session_start();
include 'connect.php';
$msg = ""; // Message variable for successful registration message

if (isset($_GET['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to the login page
    exit();
}

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        if ($row && password_verify($password, $row['lozinka'])) {
            $_SESSION['username'] = $username;
            $_SESSION['razina'] = $row['razina'];
            header("Location: login.php"); // Redirect to the same page to display the success message
            exit();
        } else {
            $msg = "Pogrešno korisničko ime ili lozinka.";
        }
    }
    mysqli_close($dbc);
}
?>

<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L'Express</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <header>
            <div><img src="img/logo.png" alt="logo" class="lexpress"></div>
        </header>
    </div>

    <nav class="navigacija">
        <div class="nav">
            <div class="container2">
                <a href="index.php">HOME</a>
                <a href="administracija.php">ADMINISTRACIJA</a>
                <a href="registracija.php">REGISTRACIJA</a>
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<a href="index.php?logout=true">ODJAVI SE</a>'; // Add the logout link
                } else {
                    echo '<a href="login.php" class="aktivan">PRIJAVA</a>';
                }
                ?>
                <a href="unos.php">UNOS VIJESTI</a>
                <a href="kategorija.php?id=SPORT">SPORT</a>
                <a href="kategorija.php?id=POLITIKA">POLITIKA</a>
            </div>
        </div>
    </nav>

    <nav class="navigacija2"></nav>

    <div class="srednji">
        <div class="container2">
            <div class="content1">
                <form enctype="multipart/form-data" action="" method="POST">
                    <div class="centar">
                        <label for="username">Korisničko ime:</label>
                        <div>
                            <input type="text" name="username" id="username" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <label for="password">Lozinka:</label>
                        <div>
                            <input type="password" name="password" id="password" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <button type="submit" name="submit" value="Prijava" id="slanje" class="gumbr">Prijavi se</button>
                    </div>
                    <?php
                    if (!empty($msg)) {
                        echo "<p class='bojaPoruke'>" . $msg . "</p>";
                    } elseif (isset($_SESSION['username'])) {
                        echo "<p class='admin'>Uspješno ste prijavljeni kao " . $_SESSION['username'];
                        if ($_SESSION['razina'] == 1) {
                            echo " (Administrator)";
                        } else {
                            echo " (Korisnik bez administratorskih prava)";
                        }
                        echo ".</p>";
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="container2">
                @ L'Express - Karlo Žerjav
            </div>
        </div>
    </footer>
</body>

</html>
