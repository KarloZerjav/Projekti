<?php
session_start();
include 'connect.php';
define('UPLPATH', 'img/');

if (isset($_GET['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to the login page
    exit();
}

// Provjera da li je korisnik došao s login forme
if (isset($_POST['prijava'])) {
    // Provjera da li korisnik postoji u bazi uz zaštitu od SQL injectiona
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];
    $sql = "SELECT korisnickoime, lozinka, razina FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    // Provjera lozinke
    if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
        $uspjesnaPrijava = true;
        // Postavljanje session varijabli
        $_SESSION['username'] = $imeKorisnika;
        $_SESSION['level'] = $levelKorisnika;
    } else {
        $uspjesnaPrijava = false;
    }
}

if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $query = "DELETE FROM vijesti WHERE id=$id";
    $result = mysqli_query($dbc, $query);
    define('UPLPATH', 'img/');
    header("Refresh:0");
}

if (isset($_POST['update'])) {
    $naslov = $_POST["title"];
    $datum = $_POST['date'];
    $kratki_sadrzaj = $_POST["about"];
    $sadrzaj = $_POST["content"];
    $kategorija = $_POST["category"];
    $archive = isset($_POST['archive']) ? 1 : 0;
    $id = $_POST['id'];

    // Provjera da li je korisnik odabrao novu sliku
    if ($_FILES['pphoto']['error'] !== 4) {
        $slika = $_FILES['pphoto']['name'];
        $target_dir = 'img/' . $slika;
        move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
    } else {
        // Koristi postojeću sliku
        $query_select = "SELECT slika FROM vijesti WHERE id=$id";
        $result_select = mysqli_query($dbc, $query_select);
        $row_select = mysqli_fetch_array($result_select);
        $slika = $row_select['slika'];
    }

    $query = "UPDATE vijesti SET naslov='$naslov', datum='$datum', sazetak='$kratki_sadrzaj', tekst='$sadrzaj', slika='$slika', kategorija='$kategorija', arhiva='$archive' WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    header("Refresh:0");
}

?>

<?php
// Provjera da li je korisnik prijavljen i ima razinu 1
if (isset($_SESSION['username']) && isset($_SESSION['level'])) {
    if ($_SESSION['level'] == 0) {
        echo 'Nemate pristup ovoj stranici.';
    } else if ($_SESSION['level'] == 1) {
        $query = "SELECT * FROM vijesti";
        $result = mysqli_query($dbc, $query);
        echo '<table>';
        while ($row = mysqli_fetch_array($result)) {
            echo '<tr>';
            echo '<td>' . $row['naslov'] . '</td>';
            echo '<td>' . $row['sazetak'] . '</td>';
            echo '<td>' . $row['datum'] . '</td>';
            echo '<td><a href="update.php?id=' . $row['id'] . '">Uredi</a></td>';
            echo '<td>
                    <form method="post" action="">
                      <input type="hidden" name="id" value="' . $row['id'] . '">
                      <input type="submit" name="delete" value="Obriši">
                    </form>
                  </td>';
            echo '</tr>';
        }
        echo '</table>';

        // Dodatak za odjavu
        echo '<a href="?logout=true">Odjava</a>';
    }
}
?>

<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L'Express</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <header>
            <div><img src="img/logo.png" alt="logo" class="lexpress"></div>
        </header>
    </div>

    <nav class="navigacija">
        <div class="nav">
            <div class="container2">
                <a href="index.php">HOME</a>
                <a href="administracija.php" class="aktivan">ADMINISTRACIJA</a>
                <a href="registracija.php">REGISTRACIJA</a>
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<a href="index.php?logout=true">ODJAVI SE</a>'; // Add the logout link
                } else {
                    echo '<a href="login.php">PRIJAVA</a>';
                }
                ?>
                <a href="unos.php">UNOS VIJESTI</a>
                <a href="kategorija.php?id=SPORT">SPORT</a>
                <a href="kategorija.php?id=POLITIKA">POLITIKA</a>
            </div>
        </div>
    </nav>

    <nav class="navigacija2"></nav>

    <div class="srednji">
        <div class="container2">
            <div class="content1">
                <?php
                if (isset($_SESSION['username']) && $_SESSION['razina'] == 1) {
                    $query = "SELECT * FROM vijesti";
                    $result = mysqli_query($dbc, $query);
                    while ($row = mysqli_fetch_array($result)) {
                        echo '<form enctype="multipart/form-data" action="" method="POST">
                <div class="centar">
                    <label for="title">Naslov vijesti</label>
                    <div>
                        <input type="text" name="title" class="form-field-textual" value="' . $row['naslov'] . '">
                    </div>
                </div>
                <div class="centar">
                    <label for="date">Datum</label>
                    <div>
                        <input type="date" name="date" class="form-field-textual" value="' . $row['datum'] . '">
                    </div>
                </div>
                <div class="centar">
                    <label for="about">Kratki sadržaj vijesti (do 50 znakova):</label>
                    <div>
                        <textarea name="about" id="" cols="30" rows="10" class="form-field-textual">' . $row['sazetak'] . '</textarea>
                    </div>
                </div>
                <div class="centar">
                    <label for="content">Sadržaj vijesti</label>
                    <div>
                        <textarea name="content" id="" cols="30" rows="10" class="form-field-textual">' . $row['tekst'] . '</textarea>
                    </div>
                </div>
                <div class="centar">
                    <label for="pphoto">Slika:</label>
                    <div>
                        <input type="file" class="input-text" id="pphoto" name="pphoto" /><br>
                        <img src="' . UPLPATH . $row['slika'] . '" width="100px">
                    </div>
                </div>
                <div class="centar">
                    <label for="category">Kategorija vijesti:</label>
                    <div>
                        <select name="category" id="" class="form-field-textual">
                            <option value="sport" ' . (($row['kategorija'] == 'sport') ? 'selected' : '') . '>Sport</option>
                            <option value="politika" ' . (($row['kategorija'] == 'politika') ? 'selected' : '') . '>Politika</option>
                        </select>
                    </div>
                </div>
                <div class="centar">
                    <label>Spremiti u arhivu:</label>
                    <div>';
                if ($row['arhiva'] == 0) {
                    echo '<input type="checkbox" name="archive" id="archive" />';
                } else {
                    echo '<input type="checkbox" name="archive" id="archive" checked />';
                }
                echo '</div>
                </div>
                <div class="centar">
                    <input type="hidden" name="id" class="form-field-textual" value="' . $row['id'] . '">
                    <button type="reset" value="Poništi" class="gumb">Poništi</button>
                    <button type="submit" name="update" value="Prihvati" class="gumb">Izmjeni</button>
                    <button type="submit" name="delete" value="Izbriši" class="gumb">Izbriši</button>
                </div>
            </form>';
                    }
                } else {
                    echo 'Nemate pristup ovoj stranici.';
                }
                ?>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer">
            <div class="container2">
                <p class="centar">@ L'Express - Karlo Žerjav</p>
            </div>
        </div>
    </footer>
</body>

</html>
