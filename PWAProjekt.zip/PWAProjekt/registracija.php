<?php
$registriranKorisnik = false;
include 'connect.php';
$msg = ""; // Message variable for successful registration message
$msge = "";
session_start();
define('UPLPATH', 'img/');
if (isset($_GET['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to the login page
    exit();
}
// Provjera da li je korisnik došao s login forme
if (isset($_POST['prijava'])) {
    // Provjera da li korisnik postoji u bazi uz zaštitu od SQL injectiona
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];
    $sql = "SELECT korisnickoime, lozinka, razina FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    // Provjera lozinke
    if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
        $uspjesnaPrijava = true;
        // Provjera da li je admin
        if ($levelKorisnika == 1) {
            $admin = true;
        } else {
            $admin = false;
        }
        // Postavljanje session varijabli
        $_SESSION['username'] = $imeKorisnika;
        $_SESSION['level'] = $levelKorisnika;
    } else {
        $uspjesnaPrijava = false;
    }
}

if (isset($_POST['submit'])) {
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $username = $_POST['username'];
    $lozinka = $_POST['pass'];
    $hashed_password = password_hash($lozinka, CRYPT_BLOWFISH);
    $razina = 0;
    $registriranKorisnik = false; // Flag variable for successful registration

    // Check if user with the same username already exists in the database
    $sql = "SELECT korisnickoime FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    if (mysqli_stmt_num_rows($stmt) > 0) {
        $msge = "Korisnik već postoji!";
    } else {
        // If the user with the same username doesn't exist, register the user
        $sql = "INSERT INTO korisnik (ime, prezime, korisnickoime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_stmt_init($dbc);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, 'ssssd', $ime, $prezime, $username, $hashed_password, $razina);
            mysqli_stmt_execute($stmt);
            $registriranKorisnik = true;
            $msg = "Uspješno registrirano!";
        }
    }
    mysqli_close($dbc);
}
?>

<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L'Express</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <header>
            <div><img src="img/logo.png" alt="logo" class="lexpress"></div>
        </header>
    </div>

    <nav class="navigacija">
        <div class="nav">
            <div class="container2">
                <a href="index.php">HOME</a>
                <a href="administracija.php">ADMINISTRACIJA</a>
                <a href="registracija.php" class="aktivan">REGISTRACIJA</a>
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<a href="index.php?logout=true">ODJAVI SE</a>'; // Add the logout link
                } else {
                    echo '<a href="login.php">PRIJAVA</a>';
                }
                ?>
                <a href="unos.php">UNOS VIJESTI</a>
                <a href="kategorija.php?id=SPORT">SPORT</a>
                <a href="kategorija.php?id=POLITIKA">POLITIKA</a>
            </div>
        </div>
    </nav>

    <nav class="navigacija2"></nav>

    <div class="srednji">
        <div class="container2">
            <div class="content1">
                <form enctype="multipart/form-data" action="" method="POST">
                    <div class="centar">
                        <span id="porukaIme" class="bojaPoruke"></span>
                        <label for="title">Ime: </label>
                        <div>
                            <input type="text" name="ime" id="ime" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <span id="porukaPrezime" class="bojaPoruke"></span>
                        <label for="about">Prezime: </label>
                        <div>
                            <input type="text" name="prezime" id="prezime" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <span id="porukaUsername" class="bojaPoruke"></span>
                        <label for="content">Korisničko ime:</label>
                        <div>
                            <input type="text" name="username" id="username" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <span id="porukaPass" class="bojaPoruke"></span>
                        <label for="pphoto">Lozinka: </label>
                        <div>
                            <input type="password" name="pass" id="pass" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <span id="porukaPassRep" class="bojaPoruke"></span>
                        <label for="pphoto">Ponovite lozinku: </label>
                        <div>
                            <input type="password" name="passRep" id="passRep" class="form-field-textual" value="">
                        </div>
                    </div>
                    <div class="centar">
                        <button type="submit" name="submit" value="Prijava" id="slanje" class="gumbr">Registriraj se</button>
                    </div>
                    <?php // Display the successful registration message
                    if ($registriranKorisnik) {
                        echo "<p class='uspjesno'>" . $msg . "</p>";
                    }else if (!empty($msge)) {
                        echo "<p class='bojaPoruke'>" . $msge . "</p>";
                    } 
                    ?>
                </form>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="container2">
                @ L'Express - Karlo Žerjav
            </div>
        </div>
    </footer>
    <script type="text/javascript">
        document.getElementById("slanje").onclick = function(event) {
            var slanjeForme = true;
            var poljeIme = document.getElementById("ime");
            var ime = document.getElementById("ime").value;
            if (ime.length == 0) {
                slanjeForme = false;
                poljeIme.style.border = "1px dashed red";
                document.getElementById("porukaIme").innerHTML = "<br>Unesite ime!<br>";
            } else {
                poljeIme.style.border = "1px solid green";
                document.getElementById("porukaIme").innerHTML = "";
            }
            var poljePrezime = document.getElementById("prezime");
            var prezime = document.getElementById("prezime").value;
            if (prezime.length == 0) {
                slanjeForme = false;
                poljePrezime.style.border = "1px dashed red";
                document.getElementById("porukaPrezime").innerHTML = "<br>Unesite prezime!<br>";
            } else {
                poljePrezime.style.border = "1px solid green";
                document.getElementById("porukaPrezime").innerHTML = "";
            }
            var poljeUsername = document.getElementById("username");
            var username = document.getElementById("username").value;
            if (username.length == 0) {
                slanjeForme = false;
                poljeUsername.style.border = "1px dashed red";
                document.getElementById("porukaUsername").innerHTML = "<br>Unesite korisničko ime!<br>";
            } else {
                poljeUsername.style.border = "1px solid green";
                document.getElementById("porukaUsername").innerHTML = "";
            }
            var poljePass = document.getElementById("pass");
            var pass = document.getElementById("pass").value;
            var poljePassRep = document.getElementById("passRep");
            var passRep = document.getElementById("passRep").value;
            if (pass.length == 0 || passRep.length == 0 || pass != passRep) {
                slanjeForme = false;
                poljePass.style.border = "1px dashed red";
                poljePassRep.style.border = "1px dashed red";
                document.getElementById("porukaPass").innerHTML = "<br>Lozinke nisu iste!<br>";
                document.getElementById("porukaPassRep").innerHTML = "<br>Lozinke nisu iste!<br>";
            } else {
                poljePass.style.border = "1px solid green";
                poljePassRep.style.border = "1px solid green";
                document.getElementById("porukaPass").innerHTML = "";
                document.getElementById("porukaPassRep").innerHTML = "";
            }
            if (!slanjeForme) {
                event.preventDefault();
            }
        };
    </script>
</body>

</html>