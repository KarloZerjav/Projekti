<?php
session_start();
include 'connect.php';
define('UPLPATH', 'img/');
if (isset($_GET['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to the login page
    exit();
}
// Provjera da li je korisnik došao s login forme
if (isset($_POST['prijava'])) {
    // Provjera da li korisnik postoji u bazi uz zaštitu od SQL injectiona
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];
    $sql = "SELECT korisnickoime, lozinka, razina FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    // Provjera lozinke
    if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
        $uspjesnaPrijava = true;
        // Provjera da li je admin
        if ($levelKorisnika == 1) {
            $admin = true;
        } else {
            $admin = false;
        }
        // Postavljanje session varijabli
        $_SESSION['username'] = $imeKorisnika;
        $_SESSION['level'] = $levelKorisnika;
    } else {
        $uspjesnaPrijava = false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'connect.php';
    $naslov = $_POST["title"];
    $datum = $_POST['date'];
    $kratki_sadrzaj = $_POST["about"];
    $sadrzaj = $_POST["content"];
    $slika = $_POST["pphoto"];
    $kategorija = $_POST["category"];
    $archive = isset($_POST['archive']) ? 1 : 0;


    $target_dir = 'img/' . $slika;
    move_uploaded_file($_POST["pphoto"], $target_dir);
    $query = "INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva ) VALUES ('$datum', '$naslov', '$kratki_sadrzaj', '$sadrzaj', '$slika', '$kategorija', '$archive')";
    $result = mysqli_query($dbc, $query) or die('Error querying databese.');
    mysqli_close($dbc);
}
?>

<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L'Express</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <header>
            <div><img src="img/logo.png" alt="logo" class="lexpress"></div>
        </header>
    </div>

    <nav class="navigacija">
        <div class="nav">
            <div class="container2">
            <a href="index.php">HOME</a>
                <a href="administracija.php">ADMINISTRACIJA</a>
                <a href="registracija.php">REGISTRACIJA</a>
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<a href="index.php?logout=true">ODJAVI SE</a>'; // Add the logout link
                } else {
                    echo '<a href="login.php">PRIJAVA</a>';
                }
                ?>
                <a href="unos.php">UNOS VIJESTI</a>
                <a href="kategorija.php?id=SPORT">SPORT</a>
                <a href="kategorija.php?id=POLITIKA">POLITIKA</a>
            </div>
        </div>
    </nav>

    <nav class="navigacija2"></nav>

    <div class="srednji">
        <div class="container2">
            <div class="content1php">
                <h3><?php echo $kategorija ?></h3>
                <h1><?php echo $naslov; ?></h1>
                <h5><?php echo "Objavljeno: $datum" ?></h5>
                <div class="article1">
                    <img src=<?php echo "img/" . $slika; ?>>
                    <p><?php echo $kratki_sadrzaj; ?></p>
                    <p><?php echo $sadrzaj; ?></p>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="container2">
                @ L'Express - Karlo Žerjav
            </div>
        </div>
    </footer>
</body>

</html>