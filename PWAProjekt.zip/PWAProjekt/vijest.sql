-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 25, 2023 at 10:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vijest`
--
CREATE DATABASE IF NOT EXISTS `vijest` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `vijest`;

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `prezime` varchar(255) NOT NULL,
  `korisnickoime` varchar(255) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `razina` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `korisnickoime`, `lozinka`, `razina`) VALUES
(11, 'Karlo', 'Žerjav', 'kzerjav', '$2y$10$xLdYFehq5mIt/PR0RneyC.CdttH.QHZ0GfWUm9DIaf4k3LoLiGMQi', '1'),
(14, 'Marko', 'Markić', 'mmarkic', '$2y$10$dgyl2gBLUrTRslInXGWZEezq001bCQBR5Jp/2XcG7RvKqXRnuuPP2', '0'),
(15, 'admin', 'admin', 'admin', '$2y$10$4GuLOQoKQ3UJoOEQsKPJJOQly.eiJYCQATPVnd6qDhUUwyjLMGmFq', '1');

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `naslov` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `sazetak` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `tekst` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `slika` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `kategorija` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(24, '2018-07-15', 'Hrvatska nogometna prezentacija', 'Hrvatska nogometna reprezentacija postigla je izvanredan uspjeh.', 'Hrvatska nogometna reprezentacija postigla je izvanredan uspjeh osvojivši drugo mjesto na Svjetskom prvenstvu 2018. godine. Nakon napetih utakmica i iznenađujućih pobjeda, Hrvatska je stigla do finala, gdje su se susreli s Francuskom, te na kraju izgubili 4:2! Osvojili su drugo mjesto.', 'hrvfr.jpeg', 'SPORT', 0),
(25, '2018-04-27', 'Povijesni sporazum', 'Sjeverna i Južna Koreja potpisale su povijesni sporazum.', 'Sjeverna i Južna Koreja potpisale su povijesni sporazum koji otvara put prema miru i denuklearizaciji Korejskog poluotoka. Sporazum je postignut tijekom summita između sjevernokorejskog vođe Kim Jong-una i južnokorejskog predsjednika Moona Jae-ina.', 'koreja.jpg', 'POLITIKA', 0),
(26, '2017-07-16', 'Roger Federer', 'Roger Federer ispisao je povijest osvojivši osmi naslov na prestižnom teniskom turniru Wimbledon.', 'Švicarski tenisač Roger Federer ispisao je povijest osvojivši osmi naslov na prestižnom teniskom turniru Wimbledon. Federer je demonstrirao izvanrednu igru i svladao protivnika u finalu, ostvarivši rekordni broj naslova na jednom Grand Slam turniru.', 'federer.png', 'sport', 1),
(27, '2023-06-19', 'Tri medalje u ovih pet godina', 'Zlatko Dalić je nogometni genij kojeg nitko nikada neće dostići!', 'Hrvatska je od SP-a u Rusiji do završnice turnira u Rotterdamu odradila šest velikih natjecanja (ako računamo Ligu nacija), u tom periodu dohvatila tri medalje. Toliko ih imaju još samo Francuska i Italija...', 'dalic.png', 'sport', 0),
(28, '2023-06-20', 'Messi ide u SAD', 'Kao veleposlanik Saudijske Arabije zarađuje promoviranjem te zemlje.', 'Leo Messi će potpisom za Inter Miami zaraditi pravo malo bogatstvo, ali Argentinac ima još jedan \"posao\" koji mu donosi prihode. Svjetski prvak sa Saudijskom Arabijom ima bogat ugovor. ', 'messi.png', 'SPORT', 0),
(29, '2023-06-19', 'Drama u reprezentaciji Belgije', 'Drama u reprezentaciji Belgije: Courtois otišao uoči utakmice', 'Golman Real Madrida nije bio zadovoljan što je Lukaku bio kapetan protiv Austrije. Izbornik ne zna kakva je njegova budućnost u reprezentaciji, a Courtois tvrdi kako na put nije otišao zbog ozljede koljena', 'golman.png', 'SPORT', 0),
(30, '2023-06-10', 'Katar i UAE', 'Katar i Ujedinjeni Arapski Emirati obnovili diplomatske odnose i otvorili veleposlanstva', 'Abu Dhabi i Doha se godinama spore oko utjecaja u regiji, uloge islama u politici i podrške za prodemokratske pokrete diljem Bliskog istoka', 'katar.png', 'POLITIKA', 0),
(32, '2023-06-09', 'Trump ima 37 novih optužbi', 'FOTO Trump ima 37 novih optužbi: Vojne tajne i nuklearni program čuvao je u kupaonici', 'U prvoj točki optužnice piše kako je Trump imao pristup najosjetljivijim povjerljivim dokumentima i informacijama o nacionalnoj sigurnosti', 'trump.png', 'POLITIKA', 0),
(33, '2023-06-07', 'Biden se obrušio na YouTube', 'To su nepromišljene odluke i vodit će čak možda i do nasilja', 'Nepromišljena i neodgovorna odluka YouTubea potaknut će daljnje propadanje demokracije i potencijalno nasilje, a mi ih pozivamo da preispitaju tu politiku, poručio je Bidenov glasnogovornik', 'biden.png', 'POLITIKA', 0),
(34, '2023-06-03', 'Američki predsjednik slavio', 'Američki predsjednik u prvom govoru iz Ovalnog ureda slavio izbjegavanje krize', 'Predsjednik je pohvalio republikanske i demokratske pregovarače i pohvalio predsjednika parlamenta Kevina McCarthyja što je radio s njim na dogovoru', 'biden2.png', 'politika', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
