<?php
include 'connect.php';
define('UPLPATH', 'img/');
$id = $_GET['id'];
$query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='$id'";
$result = mysqli_query($dbc, $query) or die('Error querying database.');
session_start();
if (isset($_GET['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php"); // Redirect to the login page
    exit();
}
// Provjera da li je korisnik došao s login forme
if (isset($_POST['prijava'])) {
    // Provjera da li korisnik postoji u bazi uz zaštitu od SQL injectiona
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];
    $sql = "SELECT korisnickoime, lozinka, razina FROM korisnik WHERE korisnickoime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    // Provjera lozinke
    if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
        $uspjesnaPrijava = true;
        // Provjera da li je admin
        if ($levelKorisnika == 1) {
            $admin = true;
        } else {
            $admin = false;
        }
        // Postavljanje session varijabli
        $_SESSION['username'] = $imeKorisnika;
        $_SESSION['level'] = $levelKorisnika;
    } else {
        $uspjesnaPrijava = false;
    }
}

?>
<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L'Express</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <header>
            <div><img src="img/logo.png" alt="logo" class="lexpress"></div>
        </header>
    </div>

    <nav class="navigacija">
        <div class="nav">
            <div class="container2">
            <a href="index.php">HOME</a>
                <a href="administracija.php">ADMINISTRACIJA</a>
                <a href="registracija.php">REGISTRACIJA</a>
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<a href="index.php?logout=true">ODJAVI SE</a>'; // Add the logout link
                } else {
                    echo '<a href="login.php" >PRIJAVA</a>';
                }
                ?>
                <a href="unos.php">UNOS VIJESTI</a>
                <a href="kategorija.php?id=SPORT">SPORT</a>
                <a href="kategorija.php?id=POLITIKA">POLITIKA</a>
            </div>
        </div>
    </nav>

    <nav class="navigacija2"></nav>

    <div class="srednji">
        <div class="container2">
            <div class="content">
                <?php
                $result = mysqli_query($dbc, $query);
                $i = 0;
                while ($row = mysqli_fetch_array($result)) {
                    echo '<div class="article">';
                    echo '<img src="' . UPLPATH . $row['slika'] . '">';
                    echo '<a class="tekst" href="clanak.php?id=' . $row['id'] . '">';
                    echo '<h6 class="crveno">' . $row['naslov'] . '</h6>';
                    echo '</a>';
                    echo '<p>' . $row['sazetak'] . '</p>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="container2">
                @ L'Express - Karlo Žerjav
            </div>
        </div>
    </footer>
</body>

</html>